import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAXa19tWnXWXRtOENl9gWlHSKhOhrxDBvs",
            authDomain: "appex-connect-wylipj.firebaseapp.com",
            projectId: "appex-connect-wylipj",
            storageBucket: "appex-connect-wylipj.appspot.com",
            messagingSenderId: "836224163861",
            appId: "1:836224163861:web:f976110ead452e85686e1c"));
  } else {
    await Firebase.initializeApp();
  }
}
