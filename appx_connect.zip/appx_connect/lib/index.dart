// Export pages
export '/pages/authenticate_solo1/authenticate_solo1_widget.dart'
    show AuthenticateSolo1Widget;
export '/pages/home_travel/home_travel_widget.dart' show HomeTravelWidget;
export '/pages/phoneverify/phoneverify_widget.dart' show PhoneverifyWidget;
export '/pages/interested/interested_widget.dart' show InterestedWidget;
export '/nearbybaches/nearbybaches_widget.dart' show NearbybachesWidget;
export '/gatewayof_india/gatewayof_india_widget.dart' show GatewayofIndiaWidget;
export '/shivaji_maharajterminus/shivaji_maharajterminus_widget.dart'
    show ShivajiMaharajterminusWidget;
export '/elephantacaves/elephantacaves_widget.dart' show ElephantacavesWidget;
export '/jahagirartgallery/jahagirartgallery_widget.dart'
    show JahagirartgalleryWidget;
export '/global_vipassana_pagoda/global_vipassana_pagoda_widget.dart'
    show GlobalVipassanaPagodaWidget;
export '/sreshivvinayak/sreshivvinayak_widget.dart' show SreshivvinayakWidget;
export '/sanjaygandhi/sanjaygandhi_widget.dart' show SanjaygandhiWidget;
export '/hajiali/hajiali_widget.dart' show HajialiWidget;
export '/mani_bhavan_gandhi_sangrahalaya/mani_bhavan_gandhi_sangrahalaya_widget.dart'
    show ManiBhavanGandhiSangrahalayaWidget;
export '/nearbyfood/nearbyfood_widget.dart' show NearbyfoodWidget;
export '/profile/profile_widget.dart' show ProfileWidget;
export '/nearbypark/nearbypark_widget.dart' show NearbyparkWidget;
export '/pages/phoneverify_copy/phoneverify_copy_widget.dart'
    show PhoneverifyCopyWidget;
export '/pages/confirm/confirm_widget.dart' show ConfirmWidget;
export '/tajhotel3/tajhotel3_widget.dart' show Tajhotel3Widget;
export '/theorchidhotel3/theorchidhotel3_widget.dart'
    show Theorchidhotel3Widget;
export '/thelalitehotel3/thelalitehotel3_widget.dart'
    show Thelalitehotel3Widget;
export '/j_w_marriott_mumbai_juhu3/j_w_marriott_mumbai_juhu3_widget.dart'
    show JWMarriottMumbaiJuhu3Widget;
export '/tajhotelreview/tajhotelreview_widget.dart' show TajhotelreviewWidget;
export '/theorcidereviewpage/theorcidereviewpage_widget.dart'
    show TheorcidereviewpageWidget;
export '/thelalitehotelreview/thelalitehotelreview_widget.dart'
    show ThelalitehotelreviewWidget;
export '/j_w_marriott_mumbai_juhureview/j_w_marriott_mumbai_juhureview_widget.dart'
    show JWMarriottMumbaiJuhureviewWidget;
export '/favourites/favourites_widget.dart' show FavouritesWidget;
export '/paymenttajhotel/paymenttajhotel_widget.dart'
    show PaymenttajhotelWidget;
export '/card_details/card_details_widget.dart' show CardDetailsWidget;
export '/paymentdone/paymentdone_widget.dart' show PaymentdoneWidget;
