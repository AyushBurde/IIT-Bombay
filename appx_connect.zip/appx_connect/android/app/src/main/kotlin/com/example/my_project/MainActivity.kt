package com.mycompany.appexconnect

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
